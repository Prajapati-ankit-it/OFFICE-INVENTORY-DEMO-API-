// eslint-disable-next-line
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div classname="App">
      {/* <logo></logo> */}
      <h1>ankit</h1>
    </div>
  );
}

export default App;
