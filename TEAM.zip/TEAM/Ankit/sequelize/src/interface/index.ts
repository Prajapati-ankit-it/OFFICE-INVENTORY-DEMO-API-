export interface ApiResponse {
    statusCode: number,
    message: string,
    data?: any
}